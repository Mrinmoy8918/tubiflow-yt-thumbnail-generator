import { Resolution, AspectRatio } from "../types";

/**
 * Standardizes the user's prompt into a base payload object.
 * This handles both plain text and JSON, converting them to a consistent structure.
 * @param prompt The user's input string.
 * @returns A record object to be used as the base for the API request.
 */
const createBasePayload = (prompt: string): Record<string, any> => {
    // Attempt to parse the prompt as a JSON object.
    try {
        const parsedJson = JSON.parse(prompt);
        // If it's a valid JSON object (and not an array or primitive), use it as the base.
        if (parsedJson && typeof parsedJson === 'object' && !Array.isArray(parsedJson)) {
            console.log("Parsed user prompt as JSON object.", parsedJson);
            return parsedJson;
        }
    } catch (e) {
        // Parsing failed, which is expected for plain text prompts. We'll fall through.
    }
    
    // If the prompt is not a valid JSON object (it's plain text, or JSON of a different type),
    // we treat the entire input as a standard text prompt to create our consistent internal structure.
    return { prompt: prompt };
};


/**
 * Sends a request to the n8n webhook to generate a thumbnail. It intelligently handles
 * a user's prompt (plain text or JSON) and UI selections, ensuring UI settings for size
 * and ratio always take priority. It sends data as separate fields when an image is present.
 *
 * @param prompt The user's prompt for the thumbnail. Can be plain text or a JSON string.
 * @param resolution The desired resolution ('2K' or '4K') from the UI.
 * @param ratio The desired aspect ratio from the UI.
 * @param referenceImages An array of files to be used as reference images.
 * @param userId The ID of the authenticated Supabase user.
 * @returns A promise that resolves with the URL of the generated image.
 */
export const generateThumbnailWithN8n = async (
    prompt: string,
    resolution: Resolution,
    ratio: AspectRatio,
    referenceImages: File[],
    userId: string,
): Promise<string> => {
    // Updated webhook URL as per the new logic description.
    const N8N_WEBHOOK_URL = 'https://mrinmoy7224.app.n8n.cloud/webhook/seedream-generate';

    // Step 1: Standardize the user's prompt (whether plain text or JSON) into a base object
    // to correctly extract the prompt text, even if other JSON fields are ignored.
    const basePayload = createBasePayload(prompt);
    
    // Step 2: Extract the final prompt text. UI selections for ratio/size will be used directly.
    const finalPromptText = basePayload.prompt || '';

    try {
        let response: Response;

        if (referenceImages.length > 0) {
            // Scenario 2: Image is Uploaded. Send as multipart/form-data with separate fields.
            const formData = new FormData();
            
            formData.append('prompt', finalPromptText);
            formData.append('ratio', ratio);
            formData.append('size', resolution);
            formData.append('userId', userId);

            referenceImages.forEach(file => {
                formData.append('file', file);
            });
            
            console.log(`Sending multipart/form-data to n8n webhook with fields: prompt='${finalPromptText}', ratio='${ratio}', size='${resolution}', userId='${userId}'`);
            response = await fetch(N8N_WEBHOOK_URL, {
                method: 'POST',
                mode: 'cors',
                body: formData, // The browser automatically sets the 'Content-Type' for FormData
            });

        } else {
            // Scenario 1: No Image is Uploaded. Send as application/json.
            const bodyPayload = JSON.stringify({
                prompt: finalPromptText,
                ratio: ratio,
                size: resolution,
                userId: userId,
            });
            
            console.log("Sending JSON payload to n8n webhook:", bodyPayload);
            response = await fetch(N8N_WEBHOOK_URL, {
                method: 'POST',
                mode: 'cors',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: bodyPayload,
            });
        }


        if (!response.ok) {
            let errorDetails = 'Could not read error response body.';
            try {
                const errorJson = await response.json();
                errorDetails = JSON.stringify(errorJson.message || errorJson, null, 2);
            } catch (e) {
                // If parsing as JSON fails, try to get the raw text response.
                errorDetails = await response.text().catch(() => 'Response body is not readable.');
            }
            throw new Error(`The generation server returned an error: ${response.status} ${response.statusText}. Details: ${errorDetails}`);
        }

        const responseText = await response.text();
        // Check for an empty response which can indicate a workflow misconfiguration.
        if (!responseText) {
            throw new Error("The generation server returned an empty response. Please check your n8n workflow configuration and ensure it returns data.");
        }

        let result;
        try {
            // The final response from the n8n workflow should always be JSON.
            result = JSON.parse(responseText);
        } catch (parseError) {
            console.error("Failed to parse JSON response from n8n:", responseText);
            throw new Error("The generation server returned an invalid (non-JSON) response. Please check your n8n workflow's final 'Respond to Webhook' node.");
        }
        
        // Validate the structure of the successful response.
        if (result && result.success === true && result.image_url) {
            return result.image_url;
        }

        // Handle structured but unsuccessful responses.
        console.error("n8n webhook response was not in the expected format or indicates failure. Response:", JSON.stringify(result, null, 2));
        if (result && result.success === false) {
             throw new Error("The generation server indicated a failure. Please check the n8n workflow execution logs for details.");
        }
        // Handle responses that are missing required fields.
        throw new Error("The server response is missing the 'image_url' or 'success' field. Expected format: { success: true, image_url: '...' }");

    } catch (error) {
        console.error('Failed to generate thumbnail via n8n webhook:', error);
        if (error instanceof Error) {
            if (error.message.includes('Failed to fetch')) {
                 throw new Error("Could not connect to the generation server. Please check your network connection and the webhook's CORS settings.");
            }
            // Re-throw the specific error message for better user feedback.
            throw new Error(`Generation failed: ${error.message}`);
        }
        throw new Error("An unknown error occurred during thumbnail generation. Please try again.");
    }
};