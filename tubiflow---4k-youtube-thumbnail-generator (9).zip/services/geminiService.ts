// This service is no longer used for thumbnail generation.
// The image generation logic has been moved to seedreamService.ts to use an n8n webhook.

export const generateThumbnail = async (prompt: string, aspectRatio: string): Promise<string> => {
    console.warn("Gemini service is deprecated. Please use the n8n service.");
    throw new Error("Gemini service is not configured. The application now uses an n8n webhook for generation.");
};
