import React, { useState, useEffect, createContext } from 'react';
import { supabase } from './supabaseClient';
import { User as SupabaseUser } from '@supabase/supabase-js';
import { AppContextType, Page, User, Plan, GeneratedImage } from './types';
import { PLANS, NEW_USER_CREDITS } from './constants';
import Header from './components/Header';
import Footer from './components/Footer';
import LandingPage from './components/LandingPage';
import AuthPage from './components/AuthPage';
import Dashboard from './components/Dashboard';
import PricingPage from './components/PricingPage';
import ProfilePage from './components/ProfilePage';
import HistoryPage from './components/HistoryPage';

export const AppContext = createContext<AppContextType | null>(null);

const App: React.FC = () => {
    const [page, setPage] = useState<Page>('landing');
    const [user, setUser] = useState<User | null>(null);
    const [history, setHistory] = useState<GeneratedImage[]>([]);
    const [sessionLoading, setSessionLoading] = useState(true);

    const fetchUserProfile = async (supabaseUser: SupabaseUser): Promise<User | null> => {
        try {
            const { data: profile, error } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', supabaseUser.id)
                .single();

            if (error && error.code !== 'PGRST116') { // PGRST116: no rows found
                throw error;
            }

            if (profile) {
                const userPlan = PLANS.find(p => p.name === profile.plan_name) || PLANS[0];
                return {
                    id: profile.id,
                    email: supabaseUser.email || '',
                    name: profile.name || supabaseUser.email?.split('@')[0] || 'Creator',
                    plan: userPlan,
                    credits: profile.credits,
                    youtube_channel_link: profile.youtube_channel_link,
                };
            } else {
                // Create a new profile for the new user
                const freePlan = PLANS[0];
                const { data: newProfile, error: insertError } = await supabase
                    .from('profiles')
                    .insert({
                        id: supabaseUser.id,
                        email: supabaseUser.email,
                        name: supabaseUser.user_metadata?.full_name || supabaseUser.email?.split('@')[0],
                        plan_name: freePlan.name,
                        credits: NEW_USER_CREDITS,
                    })
                    .select()
                    .single();

                if (insertError) throw insertError;

                return {
                    id: newProfile.id,
                    email: supabaseUser.email || '',
                    name: newProfile.name,
                    plan: freePlan,
                    credits: newProfile.credits,
                    youtube_channel_link: null,
                };
            }
        } catch (error) {
            console.error('Error fetching user profile:', error);
            return null;
        }
    };
    
    const refetchHistory = async () => {
        if (!user?.id) return;
        try {
            const { data, error } = await supabase
                .from('generations')
                .select('*')
                .eq('user_id', user.id)
                .order('created_at', { ascending: false })
                .limit(20);

            if (error) throw error;
            
            const formattedHistory = data.map(item => ({ ...item, url: item.image_url }));
            setHistory(formattedHistory);
        } catch (error) {
            console.error('Error fetching history:', error);
        }
    };
    
    useEffect(() => {
        if (user) {
            refetchHistory();
        }
    }, [user?.id]);

    useEffect(() => {
        setSessionLoading(true);
        
        supabase.auth.getSession().then(async ({ data: { session } }) => {
            if (session?.user) {
                const userProfile = await fetchUserProfile(session.user);
                setUser(userProfile);
                setPage('dashboard');
            }
            setSessionLoading(false);
        });

        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
            if (event === 'SIGNED_IN' && session?.user) {
                const userProfile = await fetchUserProfile(session.user);
                setUser(userProfile);
                setPage('dashboard');
            } else if (event === 'SIGNED_OUT') {
                setUser(null);
                setHistory([]);
                setPage('landing');
            }
        });

        return () => {
            subscription?.unsubscribe();
        };
    }, []);

    const logout = async () => {
        const { error } = await supabase.auth.signOut();
        if (error) console.error("Error logging out:", error);
    };
    
    const upgradePlan = async (plan: Plan) => {
        if (!user) throw new Error("User not logged in");
        try {
            const { data, error } = await supabase
                .from('profiles')
                .update({ plan_name: plan.name, credits: plan.credits })
                .eq('id', user.id)
                .select()
                .single();
            if (error) throw error;
            setUser(prev => prev ? { ...prev, plan, credits: data.credits } : null);
        } catch (error) {
            console.error("Error upgrading plan:", error);
            throw error;
        }
    };
    
    const spendCredits = async (amount: number) => {
        if (!user || user.credits < amount) throw new Error("Not enough credits");
        try {
            const newCredits = user.credits - amount;
            const { error } = await supabase
                .from('profiles')
                .update({ credits: newCredits })
                .eq('id', user.id);
            if (error) throw error;
            setUser(prev => prev ? { ...prev, credits: newCredits } : null);
        } catch (error) {
            console.error("Error spending credits:", error);
            throw error;
        }
    };
    
    const updateUserProfile = async (details: { name?: string; youtube_channel_link?: string }) => {
        if (!user) throw new Error("User not logged in");
        try {
            const { data, error } = await supabase
                .from('profiles')
                .update(details)
                .eq('id', user.id)
                .select()
                .single();
            if (error) throw error;
            setUser(prev => prev ? { 
                ...prev, 
                name: data.name, 
                youtube_channel_link: data.youtube_channel_link 
            } : null);
        } catch(error) {
            console.error("Error updating profile:", error);
            throw error;
        }
    };

    const renderPage = () => {
        if (sessionLoading) {
            return (
                <div className="w-full flex-grow flex justify-center items-center">
                    <div className="text-xl font-semibold text-gray-700">Loading Tubiflow...</div>
                </div>
            );
        }
        switch (page) {
            case 'auth': return <AuthPage />;
            case 'dashboard': return user ? <Dashboard /> : <LandingPage />;
            case 'pricing': return <PricingPage />;
            case 'profile': return user ? <ProfilePage /> : <AuthPage />;
            case 'history': return user ? <HistoryPage /> : <AuthPage />;
            default: return <LandingPage />;
        }
    };

    const appContextValue: AppContextType = {
        page,
        setPage,
        user,
        logout,
        upgradePlan,
        spendCredits,
        history,
        refetchHistory,
        sessionLoading,
        updateUserProfile,
    };

    return (
        <AppContext.Provider value={appContextValue}>
            <div className="min-h-screen flex flex-col bg-gray-50 font-sans text-gray-800 relative overflow-x-hidden">
                <div className="absolute top-0 -left-1/4 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-2xl opacity-30 animate-blob-spin"></div>
                <div className="absolute bottom-0 -right-1/4 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-2xl opacity-30 animate-blob-spin animation-delay-4000"></div>
                
                <Header />
                <main className="flex-grow container mx-auto px-6 py-8 pt-32">
                    {renderPage()}
                </main>
                <Footer />
            </div>
        </AppContext.Provider>
    );
};

export default App;
