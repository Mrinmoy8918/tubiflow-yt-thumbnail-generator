export type Page = 'landing' | 'auth' | 'dashboard' | 'pricing' | 'profile' | 'history';

export interface Plan {
    name: string;
    price: string;
    priceDetails: string;
    credits: number;
    features: string[];
    isPopular: boolean;
    discount?: string;
}

export interface User {
    id: string;
    email: string;
    name: string;
    plan: Plan;
    credits: number;
    youtube_channel_link?: string | null;
}

export interface AppContextType {
    page: Page;
    setPage: (page: Page) => void;
    user: User | null;
    logout: () => Promise<void>;
    upgradePlan: (plan: Plan) => Promise<void>;
    spendCredits: (amount: number) => Promise<void>;
    history: GeneratedImage[];
    refetchHistory: () => Promise<void>;
    sessionLoading: boolean;
    updateUserProfile: (details: { name?: string; youtube_channel_link?: string }) => Promise<void>;
}

export type Resolution = '2K' | '4K';

export type AspectRatio = '1:1' | '4:3' | '3:4' | '16:9' | '9:16' | '3:2' | '2:3' | '21:9';

export interface GeneratedImage {
    id: number;
    user_id: string;
    prompt: string;
    image_url: string;
    created_at: string;
    // For compatibility with existing UI that uses `url`
    url: string; 
}
