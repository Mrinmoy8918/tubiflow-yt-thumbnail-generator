import { Plan } from './types';

export const NEW_USER_CREDITS = 40;
export const GENERATION_COST = 30;

export const PLANS: Plan[] = [
    {
        name: 'Free',
        price: '₹0',
        priceDetails: '/ one-time',
        credits: 40,
        features: ['40 credits', 'Face-based Generation', '4K Quality', 'Watermark Present', '7-day history'],
        isPopular: false,
    },
    {
        name: 'Standard',
        price: '₹749',
        priceDetails: '/month',
        credits: 5000,
        features: ['5,000 credits', 'Face-based Generation', '4K Quality', 'Watermark Removed', 'Commercial Rights', 'History Retention: 180 days'],
        isPopular: false,
        discount: '20% off',
    },
    {
        name: 'Popular',
        price: '₹1,599',
        priceDetails: '/month',
        credits: 13000,
        features: ['13,000 credits', 'Face-based Generation', '4K Quality', 'Watermark Removed', 'Commercial Rights', 'History Retention: 365 days'],
        isPopular: true,
        discount: '40% off',
    },
    {
        name: 'Professional',
        price: '₹2,399',
        priceDetails: '/month',
        credits: 21000,
        features: ['21,000 credits', 'Face-based Generation', '4K Quality', 'Watermark Removed', 'Dedicated Support', 'History Retention: 365 days'],
        isPopular: false,
        discount: '45% off',
    },
];