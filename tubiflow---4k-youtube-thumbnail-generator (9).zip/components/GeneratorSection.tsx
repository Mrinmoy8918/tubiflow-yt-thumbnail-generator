import React, { useState, useContext, useCallback, useEffect } from 'react';
import { AppContext } from '../App';
import { AppContextType, Resolution, GeneratedImage, AspectRatio } from '../types';
import { generateThumbnailWithN8n } from '../services/seedreamService';
import { GENERATION_COST } from '../constants';
import InformationCircleIcon from './icons/InformationCircleIcon';

const UploadIcon: React.FC = () => (
    <svg className="w-8 h-8 mx-auto text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

const MAX_IMAGES = 5;
const MAX_FILE_SIZE_MB = 10;

const GeneratorSection: React.FC = () => {
    const { user, spendCredits, setPage, refetchHistory } = useContext(AppContext) as AppContextType;
    const [prompt, setPrompt] = useState<string>('');
    const [resolution, setResolution] = useState<Resolution>('4K');
    const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
    const [referenceImages, setReferenceImages] = useState<File[]>([]);
    const [imagePreviews, setImagePreviews] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [generatedImage, setGeneratedImage] = useState<Omit<GeneratedImage, 'id' | 'user_id' | 'created_at'> | null>(null);
    const [generationError, setGenerationError] = useState<string | null>(null);
    const [showInstructions, setShowInstructions] = useState<boolean>(true);
    const [loadingMessage, setLoadingMessage] = useState<string>('Initializing generation...');
    const [loadingProgress, setLoadingProgress] = useState(0);

    const hasEnoughCredits = user && user.credits >= GENERATION_COST;
    const canGenerate = (prompt.trim().length > 0 || referenceImages.length > 0) && !isLoading;
    
    const loadingMessages = [
        'Analyzing your prompt...',
        'Warming up the 4K render engine...',
        'Finding the most viral concepts...',
        'Applying cinematic lighting...',
        'Polishing the final details...',
    ];

    useEffect(() => {
        let messageIndex = 0;
        let intervalId: number | undefined;

        if (isLoading) {
            setLoadingMessage(loadingMessages[0]);
            intervalId = window.setInterval(() => {
                messageIndex = (messageIndex + 1) % loadingMessages.length;
                setLoadingMessage(loadingMessages[messageIndex]);
            }, 2500); // Change message every 2.5 seconds
        }

        return () => {
            if (intervalId) {
                clearInterval(intervalId);
            }
        };
    }, [isLoading]);

    useEffect(() => {
        let progressInterval: number | undefined;
        if (isLoading) {
            setLoadingProgress(0);
            progressInterval = window.setInterval(() => {
                setLoadingProgress(prev => {
                    if (prev >= 95) {
                        if (progressInterval) clearInterval(progressInterval);
                        return 95;
                    }
                    const increment = prev < 80 ? Math.random() * 5 + 2 : Math.random() * 2 + 0.5;
                    return Math.min(prev + increment, 95);
                });
            }, 400);
        }
    
        return () => {
            if (progressInterval) clearInterval(progressInterval);
        };
    }, [isLoading]);

    useEffect(() => {
        const newPreviews = referenceImages.map(file => URL.createObjectURL(file));
        setImagePreviews(newPreviews);

        // Cleanup function to revoke URLs and prevent memory leaks
        return () => {
            newPreviews.forEach(url => URL.revokeObjectURL(url));
        };
    }, [referenceImages]);

    const handleFiles = (files: FileList | null) => {
        if (files) {
            const newFiles = Array.from(files);
            const validFiles: File[] = [];
            for (const file of newFiles) {
                if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
                    alert(`File size cannot exceed ${MAX_FILE_SIZE_MB} MB. ${file.name} will not be added.`);
                    continue;
                }
                validFiles.push(file);
            }

            setReferenceImages(prevImages => {
                const combined = [...prevImages, ...validFiles];
                if (combined.length > MAX_IMAGES) {
                    alert(`You can only upload a maximum of ${MAX_IMAGES} images.`);
                }
                return combined.slice(0, MAX_IMAGES);
            });
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        handleFiles(event.target.files);
        if (event.target) {
            event.target.value = "";
        }
    };
    
    const onDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
            handleFiles(event.dataTransfer.files);
            event.dataTransfer.clearData();
        }
    }, []);

    const onDragOver = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
    };

    const handleRemoveImage = (indexToRemove: number) => {
        setReferenceImages(prev => prev.filter((_, index) => index !== indexToRemove));
    };

    const handleGenerate = async () => {
        if (!user) {
            setPage('auth');
            return;
        }
        if (!hasEnoughCredits) {
            setGenerationError(`You need at least ${GENERATION_COST} credits to generate a thumbnail.`);
            return;
        }
        if (!prompt.trim() && referenceImages.length === 0) {
            setGenerationError("Please enter a prompt or upload an image to generate a thumbnail.");
            return;
        }

        setIsLoading(true);
        setGeneratedImage(null);
        setGenerationError(null);
        try {
            const imageUrl = await generateThumbnailWithN8n(prompt, resolution, aspectRatio, referenceImages, user.id);
            
            // FIX: Add missing 'image_url' property to match the 'GeneratedImage' type.
            const newImage = { url: imageUrl, image_url: imageUrl, prompt };
            
            setGeneratedImage(newImage);
            await spendCredits(GENERATION_COST);
            await refetchHistory();

        } catch (error) {
            console.error("Error during n8n thumbnail generation:", error);
            setGenerationError((error as Error).message || "Failed to generate thumbnail. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const GeneratingIcon: React.FC = () => (
        <div className="relative w-24 h-24 mb-4">
            {/* Orbiting elements */}
            <div className="absolute inset-0 animate-spin" style={{ animationDuration: '4s' }}>
                <div className="absolute top-0 left-1/2 -ml-1.5 w-3 h-3 bg-brand-blue rounded-full opacity-70"></div>
            </div>
            <div className="absolute inset-0 animate-spin" style={{ animationDuration: '6s', animationDirection: 'reverse' }}>
                <div className="absolute bottom-0 right-1/2 -mr-1.5 w-3 h-3 bg-brand-violet rounded-full opacity-70"></div>
            </div>
            
            {/* Central element */}
            <div className="w-full h-full bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm animate-pulse-glow">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            </div>
        </div>
    );

    return (
        <div className="w-full" id="generator-section">
            <div className="flex flex-col lg:flex-row gap-8 lg:items-stretch">
                {/* Main Generator Box */}
                <div className="flex-grow bg-white/60 backdrop-blur-xl rounded-2xl p-8 shadow-xl shadow-purple-500/10 border border-gray-200">
                     <div className="-mt-4">
                        <p className="text-center text-sm font-medium text-[#777] mb-2">
                            Use your credits below to generate your next 4K thumbnail 👇
                        </p>
                        <h2 className="text-3xl font-bold text-center mb-6">Generate Your Thumbnail</h2>
                    </div>

                    <div className="mb-6 text-center">
                        <button
                            onClick={() => setShowInstructions(!showInstructions)}
                            className="inline-flex items-center justify-center text-sm font-medium text-gray-600 hover:text-brand-purple transition-colors"
                        >
                            <InformationCircleIcon className="w-5 h-5 mr-2" />
                            Tips for the best results
                            <svg xmlns="http://www.w3.org/2000/svg" className={`w-5 h-5 ml-1 transition-transform duration-300 ${showInstructions ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        {showInstructions && (
                            <div className="mt-4 p-4 bg-blue-50/50 border border-blue-200 rounded-lg text-sm text-left text-gray-700 space-y-3 animate-fade-in-up">
                                <h4 className="font-bold text-md text-brand-blue">Quick Tips for Amazing Thumbnails:</h4>
                                <ul className="space-y-3">
                                    <li className="flex items-start">
                                        <span className="mr-2 text-lg">📸</span>
                                        <div>
                                            <strong>Better Image, Better Face Match:</strong> Upload a clear, high-quality photo of a face. Whether it's from a <strong className="text-brand-purple">DSLR</strong> or a high-quality <strong className="text-brand-purple">Mobile Camera</strong>, clarity is key. The better your photo, the more accurate the face in the thumbnail will be.
                                        </div>
                                    </li>
                                    <li className="flex items-start">
                                        <span className="mr-2 text-lg">✍️</span>
                                        <div>
                                            <strong>Add Text Like a Pro:</strong> Want text on your thumbnail? Be specific! Use this format for best results: <code className="bg-gray-200 px-1 py-0.5 rounded-md text-xs font-mono">text on top left: "Your Title"</code>.
                                        </div>
                                    </li>
                                    <li className="flex items-start">
                                        <span className="mr-2 text-lg">💡</span>
                                        <div>
                                            <strong>Prompt Length Matters:</strong> For best results, keep your prompt under <strong className="text-brand-purple">600 words</strong>. Long prompts can confuse the AI, causing it to ignore details or miss key elements. A focused prompt creates a better thumbnail.
                                        </div>
                                    </li>
                                    <li className="flex items-start">
                                        <span className="mr-2 text-lg">📁</span>
                                        <div>
                                            <strong>File Size Limit:</strong> Each image you upload must be under <strong className="text-brand-purple">10MB</strong> to keep things speedy.
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="prompt-input" className="block text-sm font-medium text-gray-700 mb-1">Prompt</label>
                            <textarea
                                id="prompt-input"
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="Describe your video idea or thumbnail concept..."
                                className="w-full h-64 p-4 bg-gray-50/80 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-purple focus:border-brand-purple transition-all duration-300 resize-none"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Image</label>
                            <div 
                                onDrop={onDrop}
                                onDragOver={onDragOver}
                                className="w-full h-64 flex flex-col p-4 bg-gray-50/80 border-2 border-dashed border-gray-300 rounded-lg"
                            >
                                <input
                                    id="file-upload"
                                    name="file-upload"
                                    type="file"
                                    className="sr-only"
                                    onChange={handleFileChange}
                                    accept="image/*"
                                    multiple
                                    disabled={referenceImages.length >= MAX_IMAGES}
                                />
                                {referenceImages.length === 0 ? (
                                    <label htmlFor="file-upload" className="w-full h-full flex flex-col justify-center items-center text-center cursor-pointer rounded-lg border-2 border-dashed border-transparent hover:border-brand-purple transition-colors -m-4 p-4">
                                        <UploadIcon />
                                        <span className="mt-2 block text-sm font-semibold text-gray-600">Upload Image / Logo</span>
                                        <p className="text-xs text-gray-500">or drag and drop (up to 5 images, max 10MB each)</p>
                                    </label>
                                ) : (
                                    <div className="h-full flex flex-col">
                                        <div className="flex-grow grid grid-cols-3 gap-2 overflow-y-auto pr-2">
                                            {imagePreviews.map((src, index) => (
                                                <div key={src} className="relative group aspect-square">
                                                    <img
                                                        src={src}
                                                        alt={`Reference ${index + 1}`}
                                                        className="w-full h-full object-cover rounded-md"
                                                    />
                                                    <button
                                                        onClick={(e) => { e.preventDefault(); handleRemoveImage(index); }}
                                                        className="absolute top-1 right-1 bg-black/60 text-white rounded-full w-5 h-5 flex items-center justify-center text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500 z-10"
                                                        aria-label={`Remove image ${index + 1}`}
                                                    >
                                                        &times;
                                                    </button>
                                                </div>
                                            ))}
                                            {referenceImages.length < MAX_IMAGES && (
                                                <label htmlFor="file-upload" className="flex flex-col items-center justify-center text-center bg-gray-200/50 rounded-md cursor-pointer hover:bg-gray-300/50 transition-colors aspect-square">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                                                    </svg>
                                                    <span className="text-xs mt-1 text-gray-600">Add more</span>
                                                </label>
                                            )}
                                        </div>
                                        <div className="text-right text-xs text-gray-500 pt-1 flex-shrink-0">
                                            {referenceImages.length} / {MAX_IMAGES} uploaded
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                        <div>
                            <label htmlFor="resolution-select" className="block text-sm font-medium text-gray-700 mb-1">Size</label>
                            <select id="resolution-select" value={resolution} onChange={(e) => setResolution(e.target.value as Resolution)} className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple">
                                <option>2K</option>
                                <option>4K</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="aspect-ratio-select" className="block text-sm font-medium text-gray-700 mb-1">Ratio</label>
                            <select id="aspect-ratio-select" value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value as AspectRatio)} className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple">
                                <option value="1:1">1:1 (Square)</option>
                                <option value="4:3">4:3 (Standard)</option>
                                <option value="3:4">3:4 (Portrait)</option>
                                <option value="16:9">16:9 (YouTube)</option>
                                <option value="9:16">9:16 (Shorts/Reels)</option>
                                <option value="3:2">3:2 (Photography)</option>
                                <option value="2:3">2:3 (Portrait)</option>
                                <option value="21:9">21:9 (Cinematic)</option>
                            </select>
                        </div>
                    </div>
                    <div className="mt-8">
                        <button
                            onClick={handleGenerate}
                            disabled={!canGenerate || (user && !hasEnoughCredits)}
                            className="w-full py-4 text-lg font-bold text-white bg-gradient-to-r from-brand-purple to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100 flex items-center justify-center"
                        >
                             {isLoading ? (
                                <>
                                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    Creating your 4K thumbnail...
                                </>
                             ) : 'Generate Thumbnail'}
                        </button>
                        {user && !hasEnoughCredits && !isLoading && (
                            <p className="text-center text-red-500 text-sm mt-3 font-semibold">
                                You need {GENERATION_COST} credits to generate. Please upgrade your plan.
                            </p>
                        )}
                        {generationError && (
                            <p className="text-center text-red-500 text-sm mt-3 font-semibold">
                                {generationError}
                            </p>
                        )}
                    </div>
                </div>

                {/* Right Side Panel: Output and History */}
                <div className="w-full lg:w-[480px] flex-shrink-0">
                    <div className="bg-white/60 backdrop-blur-xl rounded-2xl p-6 shadow-xl shadow-purple-500/10 border border-gray-200 h-full flex flex-col">
                        <h3 className="text-xl font-bold mb-4 text-center">Result</h3>
                        
                        <div className="w-full bg-gray-200 rounded-lg flex items-center justify-center relative overflow-hidden flex-grow aspect-video lg:aspect-auto">
                            {isLoading && (
                                 <div className="absolute inset-0 bg-black/70 backdrop-blur-md flex flex-col items-center justify-center p-4 text-center z-20">
                                    <GeneratingIcon />
                                    <h4 className="text-white text-xl font-semibold mb-4">Generating Your Masterpiece...</h4>
                                    
                                    <div className="w-full max-w-xs mb-2">
                                        <div className="w-full bg-white/20 rounded-full h-2.5 overflow-hidden">
                                            <div 
                                                className="bg-gradient-to-r from-brand-blue to-brand-violet h-2.5 rounded-full transition-all duration-300 ease-linear" 
                                                style={{ width: `${loadingProgress}%` }}
                                            ></div>
                                        </div>
                                        <div className="flex justify-between text-white/80 text-xs font-medium mt-2 px-1">
                                            <span className="truncate pr-2">{loadingMessage}</span>
                                            <span>{Math.round(loadingProgress)}%</span>
                                        </div>
                                    </div>
                                </div>
                            )}
                            {generatedImage ? (
                                <img src={generatedImage.url} alt="Generated Thumbnail" className="w-full h-full object-cover" />
                            ) : (
                                !isLoading && <p className="text-gray-500 text-sm">Your generated thumbnail will appear here.</p>
                            )}
                        </div>

                        {generatedImage && (
                            <div className="mt-4 flex-shrink-0">
                                <a 
                                    href={generatedImage.url} 
                                    download={`imageai-thumbnail-${Date.now()}.jpg`}
                                    className="w-full flex items-center justify-center py-3 text-md font-bold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                    </svg>
                                    DOWNLOAD 4K UHD
                                </a>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GeneratorSection;