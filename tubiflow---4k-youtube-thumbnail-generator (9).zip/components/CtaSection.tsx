import React, { useContext } from 'react';
import { AppContext } from '../App';
import { AppContextType } from '../types';

const CtaSection: React.FC = () => {
    const { user, setPage } = useContext(AppContext) as AppContextType;

    const scrollToGenerator = () => {
        if (!user) {
            setPage('auth');
            return;
        }
        const generatorElement = document.getElementById('generator-section');
        if (generatorElement) {
            generatorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    };

    return (
        <section className="w-full bg-gradient-to-b from-gray-50/50 to-white py-20 px-4">
            <div className="text-center max-w-6xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold mb-6 max-w-4xl mx-auto">
                    Try Tubiflow Today — It’s Free, Fast & Unbelievably Accurate.
                </h2>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
                    <button
                        onClick={scrollToGenerator}
                        className="px-8 py-3 text-lg font-bold text-white bg-gradient-to-r from-red-500 to-red-600 rounded-full shadow-lg shadow-red-500/30 hover:shadow-xl hover:shadow-red-500/40 transform hover:scale-105 transition-all duration-300 animate-pulse-glow"
                    >
                        Generate My 4K Thumbnail
                    </button>
                    <button
                        className="px-8 py-3 text-lg font-bold text-gray-700 bg-white border border-gray-300 rounded-full shadow-md hover:shadow-lg hover:bg-gray-50 transform hover:scale-105 transition-all duration-300"
                    >
                        Watch Demo Video
                    </button>
                </div>
                <p className="text-sm text-gray-500">
                    Join thousands of creators who are already generating 4K real-face thumbnails.
                </p>
            </div>
        </section>
    );
};

export default CtaSection;