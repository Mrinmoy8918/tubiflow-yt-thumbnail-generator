import React, { useContext } from 'react';
import { AppContext } from '../App';
import { AppContextType } from '../types';

const HistoryPage: React.FC = () => {
    const { history, setPage } = useContext(AppContext) as AppContextType;

    return (
        <div className="w-full max-w-7xl mx-auto animate-fade-in-up">
            <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Generation History</h1>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                    Here are the thumbnails you've recently generated.
                </p>
            </div>
            {history.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {history.map((image) => (
                        <div key={image.id} className="bg-white/60 backdrop-blur-lg rounded-xl p-3 shadow-lg hover:shadow-2xl transition-shadow duration-300 group">
                            <div className="aspect-video rounded-lg overflow-hidden mb-3 bg-gray-200">
                                <img src={image.url} alt={image.prompt} className="w-full h-full object-cover" />
                            </div>
                            <p className="text-xs text-gray-600 truncate group-hover:whitespace-normal group-hover:overflow-visible h-8">{image.prompt}</p>
                            <a href={image.url} download={`thumbnail-${image.id}.jpg`} className="mt-2 text-center block w-full px-3 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-lg hover:scale-105 transition-transform opacity-0 group-hover:opacity-100">
                                Download
                            </a>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-white/60 backdrop-blur-lg rounded-xl">
                    <p className="text-gray-500 mb-4">You haven't generated any thumbnails yet.</p>
                    <button onClick={() => setPage('dashboard')} className="px-6 py-2 font-bold text-white bg-gradient-to-r from-brand-purple to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300">
                        Start Generating
                    </button>
                </div>
            )}
        </div>
    );
};

export default HistoryPage;
