import React from 'react';
import YouTubeIcon from './icons/YouTubeIcon';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';

const Footer: React.FC = () => {
    return (
        <footer className="w-full bg-white/50 border-t border-t-gray-200/50 backdrop-blur-sm mt-auto">
            <div className="w-full max-w-6xl mx-auto px-6 py-6 text-center text-gray-500">
                <div className="flex justify-center items-center space-x-6 mb-4">
                    <a href="#" className="text-gray-400 hover:text-[#FF0000] transition-all duration-300 transform hover:scale-110"><YouTubeIcon className="w-6 h-6" /></a>
                    <a href="#" className="text-gray-400 hover:text-[#1877F2] transition-all duration-300 transform hover:scale-110"><FacebookIcon className="w-6 h-6" /></a>
                    <a href="#" className="text-gray-400 hover:text-pink-500 transition-all duration-300 transform hover:scale-110"><InstagramIcon className="w-6 h-6" /></a>
                </div>
                 <div className="text-sm space-x-6 mb-4">
                    <a href="#" className="hover:text-brand-purple">Terms of Service</a>
                    <a href="#" className="hover:text-brand-purple">Privacy Policy</a>
                    <a href="#" className="hover:text-brand-purple">Contact Support</a>
                </div>
                <p className="text-xs">&copy; {new Date().getFullYear()} Tubiflow. All rights reserved.</p>
            </div>
        </footer>
    );
};

export default Footer;