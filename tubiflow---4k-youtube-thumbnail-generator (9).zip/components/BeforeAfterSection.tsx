import React from 'react';

const BeforeAfterSection: React.FC = () => {
    const beforeImageUrl = 'https://i.ibb.co/3y4NJ8gR/MV5-BNTQ2-MDBl-Mz-Yt-MGQx-Yy00-Nz-Uw-LTlk-YTUt-NDkz-OWM0-ZDJm-Yj-Qy-Xk-Ey-Xk-Fqc-Gc-V1.jpg';
    const afterImageUrl = 'https://i.ibb.co/bRqpQg8q/021761774268801e26ea4ff982ac6e590cb805428c1b8b8e792c1-0.jpg';

    const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
        <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
        </svg>
    );

    return (
        <section className="w-full pt-16 md:pt-20 bg-gradient-to-b from-gray-50/50 to-white/0">
            <div className="max-w-6xl mx-auto px-4">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">
                        Transform Any Image into a Viral Thumbnail
                    </h2>
                    <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                        Our AI intelligently analyzes your source image, extracts the face, and creates a stunning, click-worthy 4K thumbnail.
                    </p>
                </div>

                <div className="bg-white/60 backdrop-blur-xl rounded-3xl p-6 md:p-10 shadow-xl shadow-purple-500/10 border border-gray-200">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                        {/* Before Image */}
                        <div className="text-center">
                            <p className="text-sm font-bold tracking-wider text-gray-500 uppercase mb-2">Before</p>
                            <h3 className="text-xl font-semibold text-gray-700 mb-4">Source Image</h3>
                            <div className="bg-gradient-to-br from-blue-50 via-white to-blue-100 p-3 rounded-2xl shadow-inner border border-blue-200/50">
                                <div className="aspect-video w-full rounded-xl overflow-hidden bg-gray-200">
                                    <img
                                        src={beforeImageUrl}
                                        alt="Source portrait of Alia Bhatt for AI transformation"
                                        className="w-full h-full object-cover shadow-md"
                                    />
                                </div>
                            </div>
                             <div className="mt-4">
                                <a
                                    href={beforeImageUrl}
                                    download="source-image.jpg"
                                    className="inline-flex items-center justify-center px-6 py-2.5 text-sm font-bold text-gray-700 bg-white border border-gray-300 rounded-full shadow-md hover:shadow-lg hover:bg-gray-50 transform hover:scale-105 transition-all duration-300"
                                >
                                    <DownloadIcon className="w-5 h-5 mr-2" />
                                    Download Source
                                </a>
                            </div>
                        </div>

                        {/* After Image */}
                        <div className="text-center">
                            <p className="text-sm font-bold tracking-wider text-brand-purple uppercase mb-2">After</p>
                            <h3 className="text-xl font-semibold text-brand-purple mb-4">Generated 4K Thumbnail</h3>
                            <div className="bg-gradient-to-br from-purple-50 via-rose-50 to-purple-100 p-3 rounded-2xl shadow-lg shadow-purple-500/10 border-2 border-brand-purple/50">
                                <div className="relative rounded-xl overflow-hidden aspect-video w-full bg-gray-200">
                                    <div className="absolute top-4 right-4 bg-gradient-to-r from-brand-purple to-brand-violet text-white text-xs font-bold px-3 py-1 rounded-full z-10 animate-pulse-glow">
                                        AI Enhanced
                                    </div>
                                    <img
                                        src={afterImageUrl}
                                        alt="AI generated YouTube thumbnail of Alia Bhatt with an intense expression, in 4K quality"
                                        className="w-full h-full object-cover"
                                    />
                                </div>
                            </div>
                            <div className="mt-4">
                                <a
                                    href={afterImageUrl}
                                    download="generated-4k-thumbnail.jpg"
                                    className="inline-flex items-center justify-center px-6 py-2.5 text-sm font-bold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                                >
                                    <DownloadIcon className="w-5 h-5 mr-2" />
                                    Download 4K
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default BeforeAfterSection;