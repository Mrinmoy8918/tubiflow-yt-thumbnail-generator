import React from 'react';
import CheckIcon from './icons/CheckIcon';

const FeatureCard: React.FC<{ text: string }> = ({ text }) => (
    <div className="bg-white/60 backdrop-blur-xl rounded-2xl p-6 border border-gray-200 shadow-lg shadow-purple-500/10 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex items-center space-x-4">
        <div className="flex-shrink-0 bg-gradient-to-br from-blue-100 to-purple-200 rounded-full p-2">
            <CheckIcon className="w-6 h-6 text-brand-purple" />
        </div>
        <p className="font-semibold text-gray-800">{text}</p>
    </div>
);

const FeaturesSection: React.FC = () => {
    const features = [
        'Ultra-HD 4K Real-Face Thumbnail Output',
        'AI Engine Trained on Millions of Viral Thumbnails',
        'Designed for Every Creator Platform — YouTube, Instagram, Facebook',
        '100% Real Reference Replication — No Filters, No Fakes',
    ];

    return (
        <section className="w-full py-16 md:py-20">
            <div className="max-w-6xl mx-auto px-4">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Tubiflow Changes Everything for Creators</h2>
                    <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                        We trained our AI on crores of real thumbnails — analyzed what gets clicks and what doesn’t. 
                        This isn’t just another generator; it’s your personal viral thumbnail expert.
                    </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {features.map(feature => <FeatureCard key={feature} text={feature} />)}
                </div>
            </div>
        </section>
    );
};

export default FeaturesSection;