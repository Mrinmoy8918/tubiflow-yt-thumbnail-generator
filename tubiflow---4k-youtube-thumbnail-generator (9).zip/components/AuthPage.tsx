import React, { useState } from 'react';
import { supabase } from '../supabaseClient';

const GoogleIcon: React.FC = () => (
    <svg className="w-5 h-5 mr-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
        <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039L38.804 8.04C34.563 4.309 29.622 2 24 2C11.854 2 2 11.854 2 24s9.854 22 22 22s22-9.854 22-22c0-1.341-.138-2.65-.389-3.917z"/>
        <path fill="#FF3D00" d="M6.306 14.691c-1.229 2.196-1.996 4.79-1.996 7.618s.767 5.422 1.996 7.618l-5.01-3.87C.324 29.13 0 26.65 0 24s.324-5.13 1.296-7.519l5.01 3.21z"/>
        <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-4.752-3.636C30.41 38.381 27.38 40 24 40c-4.453 0-8.28-2.666-9.846-6.326l-5.022 3.87C11.636 41.332 17.397 44 24 44z"/>
        <path fill="#1976D2" d="M43.611 20.083H24v8h11.303c-.792 2.447-2.274 4.488-4.244 5.967l4.752 3.636C45.319 35.539 48 30.138 48 24c0-2.65-.389-5.186-1.08-7.584l-4.309 3.321z"/>
    </svg>
);

const AuthPage: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');

    const handleGoogleLogin = async () => {
        setLoading(true);
        const { error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: window.location.origin,
            },
        });
        if (error) {
            setMessage(error.message);
            setLoading(false);
        }
    };

    const handleEmailLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        if (email) {
            setLoading(true);
            setMessage('');
            try {
                const { error } = await supabase.auth.signInWithOtp({
                    email,
                    options: {
                        emailRedirectTo: window.location.origin,
                    },
                });
                if (error) throw error;
                setMessage("Check your email for the magic link!");
            } catch (error: any) {
                setMessage(error.error_description || error.message);
            } finally {
                setLoading(false);
            }
        }
    };

    return (
        <div className="w-full flex-grow flex justify-center items-center animate-fade-in-up">
            <div className="w-full max-w-md bg-white/60 backdrop-blur-xl rounded-2xl p-8 md:p-10 shadow-2xl shadow-purple-500/10 border border-white/50 relative">
                <div className="absolute -top-2 -left-2 -right-2 -bottom-2 bg-gradient-to-br from-brand-blue to-brand-violet rounded-2xl -z-10 blur-md opacity-30"></div>
                <h2 className="text-2xl md:text-3xl font-bold text-center mb-6">Create your account</h2>
                <p className="text-center text-gray-600 mb-8">Join the next generation of creators with Tubiflow.</p>
                {message && <p className="text-center text-brand-purple mb-4 font-semibold">{message}</p>}
                
                <div className="space-y-4">
                    <button onClick={handleGoogleLogin} disabled={loading} className="w-full flex items-center justify-center px-4 py-3 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 font-medium disabled:opacity-70">
                        <GoogleIcon />
                        {loading ? 'Redirecting...' : 'Continue with Google'}
                    </button>

                    <div className="relative flex py-3 items-center">
                        <div className="flex-grow border-t border-gray-300"></div>
                        <span className="flex-shrink mx-4 text-gray-500 text-sm">OR</span>
                        <div className="flex-grow border-t border-gray-300"></div>
                    </div>
                    
                    <form onSubmit={handleEmailLogin} className="space-y-4">
                        <input
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            className="w-full px-4 py-3 bg-white/80 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple focus:border-brand-purple transition"
                        />
                         <button type="submit" disabled={loading} className="w-full px-4 py-3 font-bold text-white bg-gradient-to-r from-brand-purple to-brand-violet rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-70">
                             {loading ? 'Sending...' : 'Send Magic Link'}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default AuthPage;