import React, { useContext, useState } from 'react';
import { AppContext } from '../App';
import { AppContextType, Plan } from '../types';
import { PLANS, GENERATION_COST } from '../constants';
import Modal from './Modal';
import CheckIcon from './icons/CheckIcon';

const PricingCard: React.FC<{ plan: Plan, isCurrent: boolean, onUpgrade: (plan: Plan) => void }> = ({ plan, isCurrent, onUpgrade }) => {
    const cardClasses = `relative w-full bg-white/70 backdrop-blur-lg rounded-2xl p-8 shadow-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 border ${isCurrent ? 'border-brand-purple shadow-purple-500/20' : 'border-gray-200'}`;

    return (
        <div className={cardClasses}>
            {plan.isPopular && (
                <div className="absolute top-0 -right-2 transform -translate-y-1/2 bg-gradient-to-r from-brand-purple to-brand-violet text-white text-xs font-bold px-4 py-1 rounded-full shadow-md">
                    Most Popular
                </div>
            )}
            <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
            {plan.discount && <p className="text-sm text-green-600 font-semibold mb-2">{plan.discount}</p>}
            <p className="text-4xl font-bold mb-1">{plan.price}<span className="text-lg text-gray-500 font-normal ml-1">{plan.priceDetails}</span></p>
            <ul className="mt-6 space-y-3 text-gray-600">
                {plan.features.map(feature => (
                    <li key={feature} className="flex items-center">
                        <CheckIcon className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>{feature}</span>
                    </li>
                ))}
            </ul>
            <div className="mt-8">
                {isCurrent ? (
                    <button disabled className="w-full py-3 bg-gray-200 text-gray-500 rounded-full font-semibold cursor-not-allowed">Current Plan</button>
                ) : (
                    <button onClick={() => onUpgrade(plan)} className="w-full py-3 font-bold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300">Upgrade</button>
                )}
            </div>
        </div>
    );
};


const PricingPage: React.FC = () => {
    const { user, upgradePlan, setPage } = useContext(AppContext) as AppContextType;
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
    const [isSuccess, setIsSuccess] = useState(false);
    const [isUpdating, setIsUpdating] = useState(false);

    const handleUpgradeClick = (plan: Plan) => {
        if (!user) {
            setPage('auth');
            return;
        }
        setSelectedPlan(plan);
        setIsSuccess(false);
        setIsModalOpen(true);
    };
    
    const confirmUpgrade = async () => {
        if(selectedPlan) {
            setIsUpdating(true);
            try {
                await upgradePlan(selectedPlan);
                setIsSuccess(true);
            } catch (error) {
                alert("Failed to upgrade plan. Please try again.");
                console.error(error);
            } finally {
                setIsUpdating(false);
            }
        }
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setSelectedPlan(null);
        if(isSuccess) setPage('dashboard');
    }

    return (
        <div className="w-full max-w-6xl mx-auto animate-fade-in-up">
            <Modal isOpen={isModalOpen} onClose={closeModal}>
                {selectedPlan && (
                    <div className="text-center">
                        {isSuccess ? (
                             <>
                                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
                                  <CheckIcon className="h-6 w-6 text-green-600" />
                                </div>
                                <h3 className="text-2xl font-bold mb-2">Upgrade Successful!</h3>
                                <p className="text-gray-600 mb-6">Your plan has been upgraded to {selectedPlan.name}. Your credits have been updated.</p>
                                <button onClick={closeModal} className="px-8 py-3 font-bold text-white bg-gradient-to-r from-brand-purple to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300">
                                    Go Back to Dashboard
                                </button>
                            </>
                        ) : (
                            <>
                                <h3 className="text-2xl font-bold mb-2">Upgrade to {selectedPlan.name}</h3>
                                <p className="text-gray-600 mb-6">You are about to upgrade your plan. Here are the new benefits:</p>
                                <ul className="text-left space-y-2 mb-8 max-w-xs mx-auto">
                                    {selectedPlan.features.map(f => <li key={f} className="flex items-center"><CheckIcon className="w-5 h-5 text-green-500 mr-2"/>{f}</li>)}
                                </ul>
                                <button onClick={confirmUpgrade} disabled={isUpdating} className="px-8 py-3 font-bold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-70">
                                    {isUpdating ? 'Upgrading...' : 'Confirm Upgrade'}
                                </button>
                            </>
                        )}
                    </div>
                )}
            </Modal>
            
            <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Choose Your Plan</h1>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">Unlock your creative potential with the perfect plan for your needs.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {PLANS.map(plan => (
                    <PricingCard 
                        key={plan.name} 
                        plan={plan} 
                        isCurrent={user?.plan.name === plan.name}
                        onUpgrade={handleUpgradeClick}
                    />
                ))}
            </div>
            <p className="text-center text-sm text-gray-500 mt-8">
                Each image generation costs {GENERATION_COST} credits.
            </p>
        </div>
    );
};

export default PricingPage;