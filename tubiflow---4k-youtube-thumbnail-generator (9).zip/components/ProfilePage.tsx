import React, { useState, useContext, useEffect } from 'react';
import { AppContext } from '../App';
import { AppContextType } from '../types';

const ProfilePage: React.FC = () => {
    const { user, setPage, updateUserProfile } = useContext(AppContext) as AppContextType;
    const [activeTab, setActiveTab] = useState<'profile' | 'billing'>('profile');

    const [name, setName] = useState(user?.name || '');
    const [youtubeLink, setYoutubeLink] = useState(user?.youtube_channel_link || '');
    const [isUpdating, setIsUpdating] = useState(false);
    const [updateMessage, setUpdateMessage] = useState('');
    const [updateError, setUpdateError] = useState('');

    useEffect(() => {
        if (user) {
            setName(user.name);
            setYoutubeLink(user.youtube_channel_link || '');
        }
    }, [user]);

    if (!user) return null;

    const handleUpdateProfile = async () => {
        if (name === user.name && youtubeLink === (user.youtube_channel_link || '')) {
            return;
        }
        setIsUpdating(true);
        setUpdateMessage('');
        setUpdateError('');
        try {
            await updateUserProfile({
                name,
                youtube_channel_link: youtubeLink,
            });
            setUpdateMessage('Profile updated successfully!');
            setTimeout(() => setUpdateMessage(''), 3000);
        } catch (error) {
            setUpdateError('Failed to update profile. Please try again.');
             setTimeout(() => setUpdateError(''), 3000);
        } finally {
            setIsUpdating(false);
        }
    };

    const totalCreditsForPlan = user.plan.credits;
    const creditUsagePercentage = totalCreditsForPlan > 0 ? (user.credits / totalCreditsForPlan) * 100 : 0;


    const ProfileTab: React.FC = () => (
        <div className="space-y-6">
            <div className="flex items-center space-x-6">
                <img src={`https://i.pravatar.cc/150?u=${user.email}`} alt="Profile" className="w-24 h-24 rounded-full shadow-md" />
                <div>
                    <h3 className="text-2xl font-bold">{user.name}</h3>
                    <p className="text-gray-500">{user.email}</p>
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1 block w-full p-3 bg-white/80 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple" 
                />
            </div>
             <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <input 
                    type="email" 
                    value={user.email} 
                    readOnly
                    className="mt-1 block w-full p-3 bg-gray-100/80 border border-gray-300 rounded-lg cursor-not-allowed" 
                />
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700">YouTube Channel Link</label>
                <input 
                    type="url" 
                    placeholder="https://youtube.com/..." 
                    value={youtubeLink}
                    onChange={(e) => setYoutubeLink(e.target.value)}
                    className="mt-1 block w-full p-3 bg-white/80 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple" 
                />
            </div>
             <div>
                <button 
                    onClick={handleUpdateProfile}
                    disabled={isUpdating}
                    className="px-6 py-2 font-bold text-white bg-gradient-to-r from-brand-purple to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {isUpdating ? 'Updating...' : 'Update Profile'}
                </button>
                {updateMessage && <p className="inline-block ml-4 text-sm font-semibold text-green-600">{updateMessage}</p>}
                {updateError && <p className="inline-block ml-4 text-sm font-semibold text-red-500">{updateError}</p>}
            </div>
        </div>
    );

    const BillingTab: React.FC = () => (
        <div className="space-y-6">
            <div className="p-6 bg-gray-50/50 rounded-lg border border-gray-200">
                <h4 className="font-bold text-lg mb-2">Current Plan</h4>
                <p className="text-2xl font-bold text-brand-purple mb-1">{user.plan.name} Plan</p>
                <p className="text-gray-600">Renews on: {new Date(new Date().setMonth(new Date().getMonth() + 1)).toLocaleDateString()}</p>
                 <button onClick={() => setPage('pricing')} className="mt-4 px-6 py-2 text-sm font-bold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-md hover:shadow-lg transition-all duration-300">Upgrade Plan</button>
            </div>
             <div className="p-6 bg-gray-50/50 rounded-lg border border-gray-200">
                 <h4 className="font-bold text-lg mb-4">Credit Usage</h4>
                <div className="w-full bg-gray-200 rounded-full h-4">
                    <div className="bg-gradient-to-r from-brand-blue to-brand-violet h-4 rounded-full" style={{ width: `${creditUsagePercentage}%` }}></div>
                </div>
                <p className="text-sm text-gray-600 mt-2 text-right">{user.credits} / {totalCreditsForPlan} credits remaining</p>
            </div>
            <div className="p-6 bg-gray-50/50 rounded-lg border border-gray-200">
                <h4 className="font-bold text-lg mb-4">Invoice History</h4>
                 <ul className="space-y-3">
                    <li className="flex justify-between items-center text-sm"><span>Invoice #12345 - {new Date().toLocaleDateString()}</span><a href="#" className="font-semibold text-brand-purple hover:underline">Download Invoice</a></li>
                    <li className="flex justify-between items-center text-sm"><span>Invoice #12344 - {new Date(new Date().setMonth(new Date().getMonth() - 1)).toLocaleDateString()}</span><a href="#" className="font-semibold text-brand-purple hover:underline">Download Invoice</a></li>
                 </ul>
            </div>
        </div>
    );

    return (
        <div className="w-full flex-grow flex justify-center items-center animate-fade-in-up">
            <div className="w-full max-w-6xl bg-white/60 backdrop-blur-xl rounded-2xl p-8 shadow-2xl shadow-purple-500/10 border border-gray-200">
                <h1 className="text-3xl font-bold mb-8">Profile & Billing</h1>
                <div className="border-b border-gray-200 mb-6">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        <button onClick={() => setActiveTab('profile')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-lg ${activeTab === 'profile' ? 'border-brand-purple text-brand-purple' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                            Profile
                        </button>
                         <button onClick={() => setActiveTab('billing')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-lg ${activeTab === 'billing' ? 'border-brand-purple text-brand-purple' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                            Billing
                        </button>
                    </nav>
                </div>
                <div>
                    {activeTab === 'profile' ? <ProfileTab /> : <BillingTab />}
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
