import React, { useContext } from 'react';
import { AppContext } from '../App';
import { AppContextType } from '../types';

const Header: React.FC = () => {
    const { user, setPage, logout, page } = useContext(AppContext) as AppContextType;

    const navItems = user ? [
        { name: 'Dashboard', page: 'dashboard' },
        { name: 'History', page: 'history' },
        { name: 'Pricing', page: 'pricing' },
        { name: 'Profile', page: 'profile' },
    ] : [];

    return (
        <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-lg">
            <div className="container mx-auto px-6 py-4 flex justify-between items-center border-b border-gray-200/50">
                <div 
                    className="text-2xl font-bold cursor-pointer text-transparent bg-clip-text bg-gradient-to-r from-brand-blue to-brand-violet"
                    onClick={() => setPage(user ? 'dashboard' : 'landing')}
                >
                    Tubiflow 1.0
                </div>
                <nav className="flex items-center space-x-6">
                    {user ? (
                        <>
                            {navItems.map(item => (
                                <button
                                    key={item.name}
                                    onClick={() => setPage(item.page as any)}
                                    className={`transition-colors duration-300 ${page === item.page ? 'text-brand-purple font-bold' : 'text-gray-600 hover:text-brand-purple'}`}
                                >
                                    {item.name}
                                </button>
                            ))}
                            <button
                                onClick={logout}
                                className="px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-brand-violet to-brand-purple rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                            >
                                Log Out
                            </button>
                        </>
                    ) : (
                        <>
                             <button
                                onClick={() => setPage('pricing')}
                                className={`transition-colors duration-300 font-medium ${page === 'pricing' ? 'text-brand-purple font-bold' : 'text-gray-600 hover:text-brand-purple'}`}
                            >
                                Pricing
                            </button>
                             <button
                                onClick={() => setPage('auth')}
                                className="px-6 py-2 text-sm font-semibold text-white bg-gradient-to-r from-brand-blue to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                            >
                                Sign In
                            </button>
                        </>
                    )}
                </nav>
            </div>
        </header>
    );
};

export default Header;