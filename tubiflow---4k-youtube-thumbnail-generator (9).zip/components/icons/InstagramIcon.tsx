import React from 'react';

const InstagramIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="url(#instagram-gradient)">
        <defs>
            <radialGradient id="instagram-gradient" cx="30%" cy="107%" r="150%">
                <stop offset="0%" style={{ stopColor: '#f58529' }} />
                <stop offset="50%" style={{ stopColor: '#dd2a7b' }} />
                <stop offset="100%" style={{ stopColor: '#8134af' }} />
            </radialGradient>
        </defs>
        <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2C22,19.4 19.4,22 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8C2,4.6 4.6,2 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4A3.6,3.6 0 0,0 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6A3.6,3.6 0 0,0 16.4,4H7.6M17.2,6A1.2,1.2 0 0,1 18.4,7.2A1.2,1.2 0 0,1 17.2,8.4A1.2,1.2 0 0,1 16,7.2A1.2,1.2 0 0,1 17.2,6M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" />
    </svg>
);

export default InstagramIcon;