import React, { useContext } from 'react';
import { AppContext } from '../App';
import { AppContextType } from '../types';
import { GENERATION_COST } from '../constants';

const CreditIcon: React.FC = () => (
    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-blue to-brand-violet flex items-center justify-center shadow-lg shadow-blue-500/30">
        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
);


const CreditPanel: React.FC = () => {
    const { user, setPage } = useContext(AppContext) as AppContextType;

    if (!user) return null;

    const needsCredits = user.credits < GENERATION_COST;

    return (
        <div className="w-full p-[2px] rounded-2xl bg-gradient-to-br from-brand-blue via-brand-purple to-brand-violet shadow-xl shadow-purple-500/10 relative z-10">
            <div className="w-full bg-white/80 backdrop-blur-2xl rounded-[15px] p-8 flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0 md:space-x-8">
                <div className="flex items-center space-x-6">
                    <CreditIcon />
                    <div>
                        <p className="text-sm text-gray-600">Credits</p>
                        <p className={`text-4xl font-bold transition-colors duration-300 ${needsCredits ? 'text-red-500' : 'text-transparent bg-clip-text bg-gradient-to-r from-brand-blue to-brand-purple'}`}>{user.credits}</p>
                    </div>
                </div>
                
                <div className="flex flex-col items-center md:items-end text-center md:text-right space-y-2">
                     {user.plan.name === 'Free' ? (
                         <p className="text-sm text-gray-600">You are on the <span className="font-semibold text-brand-purple">Free Plan</span>. Upgrade to unlock full 4K access.</p>
                     ) : (
                        <p className="text-sm text-gray-600">Your Plan: <span className="font-semibold text-brand-purple">Monthly – {user.plan.name}</span></p>
                     )}
                     {needsCredits && (
                         <p className="text-xs text-red-500 font-semibold">You need {GENERATION_COST} credits to generate a thumbnail.</p>
                     )}
                </div>

                <button
                    onClick={() => setPage('pricing')}
                    className="px-6 py-2.5 font-bold text-white bg-gradient-to-r from-brand-purple to-brand-violet rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 animate-pulse-glow"
                >
                    Upgrade Plan
                </button>
            </div>
        </div>
    );
};

export default CreditPanel;