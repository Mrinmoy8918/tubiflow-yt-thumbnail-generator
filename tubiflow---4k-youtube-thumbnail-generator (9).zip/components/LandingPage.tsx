import React from 'react';
import GeneratorSection from './GeneratorSection';
import FeaturesSection from './FeaturesSection';
import CtaSection from './CtaSection';
import YouTubeIcon from './icons/YouTubeIcon';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';
import BeforeAfterSection from './BeforeAfterSection';
import BeforeAfterSection2 from './BeforeAfterSection2';

const HighlightedText: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-500 font-bold drop-shadow-[0_2px_2px_rgba(154,77,255,0.4)]">
        {children}
    </span>
);

const LandingPage: React.FC = () => {
    return (
        <div className="w-full flex flex-col items-center animate-fade-in-up">
            {/* Hero Section */}
            <section className="w-full text-center py-20 md:py-24">
                <div className="max-w-6xl mx-auto px-4">
                    <h1 className="text-4xl md:text-6xl font-bold leading-tight tracking-tighter mb-4">
                        World’s 1st <HighlightedText>4K YouTube</HighlightedText> Thumbnail <HighlightedText>AI Generator</HighlightedText> – Tubiflow 1.0
                    </h1>
                    <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-6">
                        Create Viral, Eye-Catching <HighlightedText>Real-Face</HighlightedText> Thumbnails That Get Clicked Instantly.
                    </p>
                    <div className="mb-8">
                        <p className="text-sm text-gray-500 mb-4">Built for YouTube, Facebook & Instagram creators.</p>
                        <div className="flex justify-center items-center space-x-6">
                            <YouTubeIcon className="w-10 h-10 text-[#FF0000] transform hover:scale-110 transition-transform duration-300 animate-pulse-glow" />
                            <FacebookIcon className="w-9 h-9 text-[#1877F2] transform hover:scale-110 transition-transform duration-300 animate-pulse-glow" />
                            <InstagramIcon className="w-9 h-9 transform hover:scale-110 transition-transform duration-300 animate-pulse-glow" />
                        </div>
                    </div>
                </div>
            </section>

            {/* Generator Section is now part of the landing page */}
            <div className="w-full max-w-7xl -mt-20 z-10">
                <div className="bg-gradient-to-b from-transparent via-white/50 to-white pt-10 rounded-t-3xl">
                     <GeneratorSection />
                </div>
            </div>
            
            <FeaturesSection />
            <BeforeAfterSection />
            <BeforeAfterSection2 />
            <CtaSection />
        </div>
    );
};

export default LandingPage;