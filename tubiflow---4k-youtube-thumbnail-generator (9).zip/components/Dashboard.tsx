import React from 'react';
import CreditPanel from './CreditPanel';
import GeneratorSection from './GeneratorSection';
import YouTubeIcon from './icons/YouTubeIcon';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';
import FeaturesSection from './FeaturesSection';
import CtaSection from './CtaSection';
import BeforeAfterSection from './BeforeAfterSection';
import BeforeAfterSection2 from './BeforeAfterSection2';

const HighlightedText: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-500 font-bold">
        {children}
    </span>
);

const Dashboard: React.FC = () => {
    return (
        <div className="w-full flex flex-col items-center animate-fade-in-up">
            {/* Top Hero Section */}
            <div className="text-center w-full max-w-6xl mx-auto py-8">
                <h1 className="text-3xl md:text-5xl font-bold max-w-4xl mx-auto leading-tight tracking-tighter mb-4">
                    World’s 1st <HighlightedText>4K YouTube</HighlightedText> Thumbnail <HighlightedText>Generator</HighlightedText> – Tubiflow 1.0
                </h1>
                <p className="text-lg text-gray-600 mb-6">
                    Trained on crores of real thumbnails — made for creators like you.
                </p>
                <div className="flex justify-center items-center space-x-6">
                    <YouTubeIcon className="w-10 h-10 text-[#FF0000] transform hover:scale-110 transition-transform duration-300 animate-pulse-glow" />
                    <FacebookIcon className="w-9 h-9 text-[#1877F2] transform hover:scale-110 transition-transform duration-300 animate-pulse-glow" />
                    <InstagramIcon className="w-9 h-9 transform hover:scale-110 transition-transform duration-300 animate-pulse-glow" />
                </div>
            </div>
            
            {/* Unified Credit and Generator Section */}
            <div className="w-full max-w-7xl bg-gradient-to-b from-[#F9F7FF] to-white rounded-3xl py-10 px-6 md:px-10 mt-8">
                <CreditPanel />
                <div className="mt-10">
                    <GeneratorSection />
                </div>
            </div>

            <FeaturesSection />
            <BeforeAfterSection />
            <BeforeAfterSection2 />
            <CtaSection />
        </div>
    );
};

export default Dashboard;