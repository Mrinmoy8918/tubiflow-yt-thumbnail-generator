import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://rpoafltkfhwdfqnkwfwp.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJwb2FmbHRrZmh3ZGZxbmt3ZndwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwODY2OTUsImV4cCI6MjA3NzY2MjY5NX0.imWqSmEggP9XvutZTS_amDA2iSNrC8iNnS6bpfdeQ2c";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
